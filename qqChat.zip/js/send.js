let sendModule = {
  // chat-ipt
  // send-btn
  chatIpt: document.getElementById('chat-ipt'),
  sendBtn: document.getElementById('send-btn'),
  oUl: document.querySelector('.chat__list'),
  messageJSONS: [{
    avatar: './img/normal.0447fe9.png',
    index: '好的啊'
  }],
  init: function () {
    this.addEvents();
  },
  initHtml: function() {
      this.oUl.innerHTML = this.messageJSONS.map(item => {
      return `<li class="chat-item">
              <div class="chat__item">
              <img src="${item.avatar}" alt="" class="avatar">
              <p class="chat__index">${item.index}</p>
              </div>
              </li>`;
    }).join('');
  },
  addEvents: function () {
    let that = this;
    this.chatIpt.addEventListener('input', function (e) { 
      e.preventDefault();
      let message = this.value.trim();
      if (message) {
        that.sendBtn.removeAttribute('disabled');
      } else {
        that.sendBtn.setAttribute('disabled', 'disabled');
      }
    })
    this.sendBtn.addEventListener('click',function(){
            let messageString = `{"avatar":"./img/normal.0447fe9.png","index":"${that.chatIpt.value.trim()}"}`;
            messageString = JSON.parse(messageString);
            that.messageJSONS.push(messageString);
            that.chatIpt.value='';
            that.initHtml();
    })
  }
}

sendModule.init();